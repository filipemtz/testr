#include <stdio.h> 

int main()
{
	int val;
	scanf("%d", val);
	printf("%d\n", double(val)); 
	return 0;
}