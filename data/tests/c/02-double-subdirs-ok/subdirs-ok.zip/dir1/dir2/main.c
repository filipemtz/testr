#include <stdio.h> 

int main()
{
	int val;
	scanf("%d", &val);
	printf("%d\n", val * 2); 
	return 0;
}